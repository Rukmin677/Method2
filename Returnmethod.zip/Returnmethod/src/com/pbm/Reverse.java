package com.pbm;

public class Reverse {
	public void reverse(int n) {
		int temp=n;
		int rev=0;
		int digit;
		while(n!=0) {
			digit=n%10;
			rev=rev*10+digit;
			temp=n/=10;

		}
		System.out.println(rev);
		
		
	}

}
