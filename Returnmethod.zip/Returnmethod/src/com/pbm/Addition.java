package com.pbm;

public class Addition {
	public static void main(String[] args) {
		Addition.myAdd(5, 7);
		
	}
	public static int myAdd(int a,int b) {
		int c=a+b;
		System.out.println(c);
		return c;
		
	}

}
