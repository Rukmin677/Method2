package com.pbm;

public class Squre {
	public void tk(int n) {
		System.out.println(n*n);
	}

}
