package com.pbm;

public class Function {
	public static void main(String[] args) {
		Even an=new Even();
		an.even(5);
		Squre ab=new Squre();
		ab.tk(3);
		cube cg=new cube();
		cg.cube(9);
		Reverse re=new Reverse();
		re.reverse(89);
	}

}
