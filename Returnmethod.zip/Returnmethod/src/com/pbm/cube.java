package com.pbm;

public class cube {
	public void cube(int n) {
		System.out.println(n*n*n);
	}

}
