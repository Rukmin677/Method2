package com.pbm;

public class Even {
	public void even(int n) {
		if(n%2==0) {
			System.out.println(" the given number is even");
		}else {
			System.out.println("the given number is odd");
		}
	}

}
